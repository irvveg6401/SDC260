// SBR Clothing - Main JavaScript
// Created by: Irvin Vega


// ==========================================
// 1. PRODUCT LIST
// ==========================================

const products = [
    {
        id: 1,
        name: "Classic Tee",
        price: 24.99,
        stock: 15,
        image: "images/classic-tee.jpg",
        description: "A comfortable everyday t-shirt."
    },
    {
        id: 2,
        name: "Essential Hoodie",
        price: 49.99,
        stock: 10,
        image: "images/essential-hoodie.jpg",
        description: "A soft hoodie for everyday wear."
    },
    {
        id: 3,
        name: "Everyday Jeans",
        price: 44.99,
        stock: 12,
        image: "images/everyday-jeans.jpg",
        description: "Classic jeans with a comfortable fit."
    },
    {
        id: 4,
        name: "SBR Graphic Tee",
        price: 27.99,
        stock: 8,
        image: "images/graphic-tee.jpg",
        description: "A stylish graphic t-shirt."
    },
    {
        id: 5,
        name: "Classic Joggers",
        price: 34.99,
        stock: 10,
        image: "images/classic-joggers.png",
        description: "Comfortable joggers for everyday use."
    },
    {
        id: 6,
        name: "Zip-Up Jacket",
        price: 54.99,
        stock: 6,
        image: "images/zip-jacket.png",
        description: "A simple and versatile zip-up jacket."
    },
    {
        id: 7,
        name: "Crewneck Sweatshirt",
        price: 42.99,
        stock: 9,
        image: "images/crewneck.png",
        description: "A comfortable classic sweatshirt."
    },
    {
        id: 8,
        name: "Cargo Pants",
        price: 46.99,
        stock: 7,
        image: "images/cargo-pants.png",
        description: "Modern cargo pants with extra pockets."
    },
    {
        id: 9,
        name: "Everyday Cap",
        price: 19.99,
        stock: 14,
        image: "images/everyday-cap.png",
        description: "A simple cap to complete your outfit."
    },
    {
        id: 10,
        name: "Canvas Tote",
        price: 16.99,
        stock: 20,
        image: "images/canvas-tote.png",
        description: "A reusable everyday canvas bag."
    }
];


// ==========================================
// 2. CART AND INVENTORY STORAGE
// ==========================================

const CART_KEY = "sbrCart";
const INVENTORY_KEY = "sbrInventory";

function loadCart() {
    try {
        return JSON.parse(localStorage.getItem(CART_KEY)) || [];
    } catch {
        return [];
    }
}

function loadInventory() {
    try {
        const savedInventory = JSON.parse(
            localStorage.getItem(INVENTORY_KEY)
        );

        if (savedInventory) {
            return savedInventory;
        }
    } catch {
        // Use starting inventory if saved data is invalid.
    }

    const startingInventory = {};

    products.forEach(function (product) {
        startingInventory[product.id] = product.stock;
    });

    localStorage.setItem(
        INVENTORY_KEY,
        JSON.stringify(startingInventory)
    );

    return startingInventory;
}

let cart = loadCart();
let inventory = loadInventory();

function saveCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function saveInventory() {
    localStorage.setItem(
        INVENTORY_KEY,
        JSON.stringify(inventory)
    );
}

function money(amount) {
    return "$" + amount.toFixed(2);
}


// ==========================================
// 3. PRODUCT DISPLAY
// ==========================================

function renderProducts() {
    const productContainer = document.getElementById("product-container");

    if (!productContainer) {
        return;
    }

    productContainer.innerHTML = "";

    products.forEach(function (product) {
        const stock = inventory[product.id];

        const productCard = document.createElement("div");

        productCard.className = "product-card";

        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}">

            <h3>${product.name}</h3>

            <p>${product.description}</p>

            <p class="product-price">${money(product.price)}</p>

            <p class="stock-status">
                ${stock > 0 ? stock + " available" : "Out of Stock"}
            </p>

            <button
                data-add-to-cart="${product.id}"
                ${stock <= 0 ? "disabled title='Out of Stock'" : ""}
                class="${stock <= 0 ? "out-of-stock" : ""}">
                ${stock > 0 ? "Add to Cart" : "Out of Stock"}
            </button>
        `;

        productContainer.appendChild(productCard);
    });
}


// ==========================================
// 4. ADD PRODUCTS TO CART
// ==========================================

function addToCart(productId) {
    const product = products.find(function (item) {
        return item.id === productId;
    });

    if (!product || inventory[productId] <= 0) {
        showCartMessage("Sorry, this product is out of stock.");
        return;
    }

    const cartItem = cart.find(function (item) {
        return item.id === productId;
    });

    if (cartItem) {
        cartItem.quantity++;
    } else {
        cart.push({
            id: productId,
            quantity: 1
        });
    }

    inventory[productId]--;

    saveCart();
    saveInventory();

    updateCartCount();
    renderCart();
    renderProducts();

    showCartMessage(product.name + " added to your cart!");
}


// Listen for Add to Cart buttons
document.addEventListener("click", function (event) {
    const button = event.target.closest("[data-add-to-cart]");

    if (!button) {
        return;
    }

    const productId = Number(button.dataset.addToCart);

    addToCart(productId);
});


// ==========================================
// 5. DISPLAY SHOPPING CART
// ==========================================

function updateCartCount() {
    const cartCount = document.querySelector(".cart-count");

    if (!cartCount) {
        return;
    }

    let totalItems = 0;

    cart.forEach(function (item) {
        totalItems += item.quantity;
    });

    cartCount.textContent = totalItems;
}

function renderCart() {
    const cartItems = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");

    if (!cartItems || !cartTotal) {
        return;
    }

    cartItems.innerHTML = "";

    let total = 0;

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <p class="empty-cart">Your cart is empty.</p>
        `;

        cartTotal.textContent = money(0);
        return;
    }

    cart.forEach(function (item) {
        const product = products.find(function (product) {
            return product.id === item.id;
        });

        if (!product) {
            return;
        }

        const itemTotal = product.price * item.quantity;

        total += itemTotal;

        const cartRow = document.createElement("div");

        cartRow.className = "cart-row";

        cartRow.innerHTML = `
            <div>
                <h3>${product.name}</h3>

                <p>${money(product.price)} each</p>

                <div class="quantity-control">
                    <button data-action="decrease" data-id="${product.id}">
                        -
                    </button>

                    <span>${item.quantity}</span>

                    <button
                        data-action="increase"
                        data-id="${product.id}"
                        ${inventory[product.id] <= 0 ? "disabled title='Out of Stock'" : ""}>
                        +
                    </button>
                </div>
            </div>

            <div>
                <p>${money(itemTotal)}</p>

                <button
                    class="remove-button"
                    data-action="remove"
                    data-id="${product.id}">
                    Remove
                </button>
            </div>
        `;

        cartItems.appendChild(cartRow);
    });

    cartTotal.textContent = money(total);
}


// ==========================================
// 6. CHANGE QUANTITIES AND REMOVE PRODUCTS
// ==========================================

document.addEventListener("click", function (event) {
    const button = event.target.closest("[data-action]");

    if (!button) {
        return;
    }

    const productId = Number(button.dataset.id);
    const action = button.dataset.action;

    const cartItem = cart.find(function (item) {
        return item.id === productId;
    });

    if (!cartItem) {
        return;
    }

    if (action === "increase") {
        if (inventory[productId] <= 0) {
            showCartMessage("No more stock available.");
            return;
        }

        cartItem.quantity++;
        inventory[productId]--;
    }

    if (action === "decrease") {
        if (cartItem.quantity > 1) {
            cartItem.quantity--;
            inventory[productId]++;
        }
    }

    if (action === "remove") {
        inventory[productId] += cartItem.quantity;

        cart = cart.filter(function (item) {
            return item.id !== productId;
        });
    }

    saveCart();
    saveInventory();

    updateCartCount();
    renderCart();
    renderProducts();
});


// ==========================================
// 7. CLEAR CART AND COMPLETE ORDER
// ==========================================

function clearCart() {
    cart.forEach(function (item) {
        inventory[item.id] += item.quantity;
    });

    cart = [];

    saveCart();
    saveInventory();

    updateCartCount();
    renderCart();
    renderProducts();
}

function completeOrder() {
    // Keep inventory reduced after a successful purchase.
    cart = [];

    saveCart();
    updateCartCount();
    renderCart();
}


// ==========================================
// 8. FLOATING CART PANEL
// ==========================================

function openCart() {
    const panel = document.getElementById("cart-panel");
    const overlay = document.getElementById("cart-overlay");

    if (!panel || !overlay) {
        return;
    }

    panel.classList.add("open");
    overlay.classList.add("open");

    panel.setAttribute("aria-hidden", "false");
    panel.inert = false;
}

function closeCart() {
    const panel = document.getElementById("cart-panel");
    const overlay = document.getElementById("cart-overlay");

    if (!panel || !overlay) {
        return;
    }

    panel.classList.remove("open");
    overlay.classList.remove("open");

    panel.setAttribute("aria-hidden", "true");
    panel.inert = true;
}

const openCartButton = document.getElementById("open-cart");
const closeCartButton = document.getElementById("close-cart");
const cartOverlay = document.getElementById("cart-overlay");
const clearCartButton = document.getElementById("clear-cart");
const continueShoppingButton = document.getElementById("continue-shopping");

if (openCartButton) {
    openCartButton.addEventListener("click", openCart);
}

if (closeCartButton) {
    closeCartButton.addEventListener("click", closeCart);
}

if (cartOverlay) {
    cartOverlay.addEventListener("click", closeCart);
}

if (clearCartButton) {
    clearCartButton.addEventListener("click", clearCart);
}

if (continueShoppingButton) {
    continueShoppingButton.addEventListener("click", closeCart);
}


// ==========================================
// 9. CART FEEDBACK MESSAGE
// ==========================================

function showCartMessage(message) {
    let messageBox = document.getElementById("cart-feedback");

    if (!messageBox) {
        messageBox = document.createElement("div");

        messageBox.id = "cart-feedback";
        messageBox.className = "cart-toast";

        document.body.appendChild(messageBox);
    }

    messageBox.textContent = message;
    messageBox.classList.add("show");

    setTimeout(function () {
        messageBox.classList.remove("show");
    }, 2500);
}


// ==========================================
// 10. CONTACT FORM
// ==========================================

function setupContactForm() {
    const contactForm = document.getElementById("contact-form");

    if (!contactForm) {
        return;
    }

    contactForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const feedback = document.getElementById("contact-feedback");

        if (!contactForm.checkValidity()) {
            contactForm.reportValidity();
            return;
        }

        if (feedback) {
            feedback.textContent =
                "Thank you! Your message has been received.";
        }

        contactForm.reset();
    });
}


// ==========================================
// 11. CHECKOUT AND COUPONS
// ==========================================

let appliedDiscount = 0;

const coupons = {
    SBR10: 10,
    SBR15: 15,
    WELCOME20: 20
};

function displayCheckout() {
    const checkoutItems = document.getElementById("checkout-items");

    if (!checkoutItems) {
        return;
    }

    checkoutItems.innerHTML = "";

    let subtotal = 0;

    cart.forEach(function (item) {
        const product = products.find(function (product) {
            return product.id === item.id;
        });

        if (!product) {
            return;
        }

        const itemTotal = product.price * item.quantity;

        subtotal += itemTotal;

        const row = document.createElement("div");

        row.innerHTML = `
            <p>
                ${product.name} x ${item.quantity}
                <span>${money(itemTotal)}</span>
            </p>
        `;

        checkoutItems.appendChild(row);
    });

    const discount = subtotal * (appliedDiscount / 100);
    const total = subtotal - discount;

    document.getElementById("checkout-subtotal").textContent =
        money(subtotal);

    document.getElementById("checkout-discount").textContent =
        money(discount);

    document.getElementById("checkout-total").textContent =
        money(total);

    const placeOrderButton = document.getElementById("place-order");

    if (placeOrderButton) {
        placeOrderButton.disabled = cart.length === 0;
    }
}


// Apply coupon code
function setupCoupon() {
    const couponButton = document.getElementById("apply-coupon");

    if (!couponButton) {
        return;
    }

    couponButton.addEventListener("click", function () {
        const couponInput = document.getElementById("coupon-code");
        const feedback = document.getElementById("coupon-feedback");

        const code = couponInput.value.trim().toUpperCase();

        if (coupons[code]) {
            appliedDiscount = coupons[code];

            feedback.textContent =
                "Coupon applied! You saved " + appliedDiscount + "%.";

            feedback.className = "success-message";
        } else {
            appliedDiscount = 0;

            feedback.textContent =
                "Invalid coupon code. Please try again.";

            feedback.className = "error-message";
        }

        displayCheckout();
    });
}


// ==========================================
// 12. PLACE ORDER AND CONFIRMATION
// ==========================================

function generateOrderNumber() {
    return "SBR-" + Math.floor(100000 + Math.random() * 900000);
}

function setupCheckoutForm() {
    const checkoutForm = document.getElementById("checkout-form");

    if (!checkoutForm) {
        return;
    }

    checkoutForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const feedback = document.getElementById("checkout-feedback");

        if (cart.length === 0) {
            feedback.textContent = "Your cart is empty.";
            return;
        }

        if (!checkoutForm.checkValidity()) {
            checkoutForm.reportValidity();
            return;
        }

        let subtotal = 0;

        cart.forEach(function (item) {
            const product = products.find(function (product) {
                return product.id === item.id;
            });

            if (product) {
                subtotal += product.price * item.quantity;
            }
        });

        const discount = subtotal * (appliedDiscount / 100);
        const finalTotal = subtotal - discount;

        const confirmation = document.getElementById("order-confirmation");

        if (confirmation) {
            document.getElementById("order-number").textContent =
                generateOrderNumber();

            document.getElementById("confirmation-total").textContent =
                money(finalTotal);

            confirmation.hidden = false;
        }

        feedback.textContent = "Your order was successfully placed!";

        // Clear purchased items without restoring inventory.
        completeOrder();

        checkoutForm.reset();

        appliedDiscount = 0;

        const couponFeedback = document.getElementById("coupon-feedback");

        if (couponFeedback) {
            couponFeedback.textContent = "";
        }

        displayCheckout();

        if (confirmation) {
            confirmation.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
}


// ==========================================
// 13. START THE WEBSITE
// ==========================================

renderProducts();
renderCart();
updateCartCount();

setupContactForm();
setupCoupon();
setupCheckoutForm();

displayCheckout();