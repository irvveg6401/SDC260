SBR CLOTHING - ECPI PROJECT WEEK 3

This version combines the Home/Shop, Cart, Contact, and Checkout pages into ONE HTML file: SBR-clothing.html.

Keep these three files in the same project folder:
- SBR-clothing.html (all website sections and forms)
- SBR-clothing-stylesheet.css (external styling)
- script.js (product loop, cart, form validation, and coupon calculations)

To test: open SBR-clothing.html in a web browser. Use Add to Cart, open the Cart section, and proceed to Checkout. Test coupon codes SBR10, SBR15, and WELCOME20.

Checkout is a classroom demonstration only. Do not enter real payment details. No payment is processed or stored.
