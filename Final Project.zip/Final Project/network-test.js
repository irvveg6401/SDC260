document.addEventListener("DOMContentLoaded", function () {

    // Get local hostname
    document.getElementById("hostname").textContent =
        window.location.hostname || "Not available";

    // Get communication port
    document.getElementById("port").textContent =
        window.location.port || "Default port (80 or 443)";

    // Get transmission protocol
    document.getElementById("protocol").textContent =
        window.location.protocol.replace(":", "").toUpperCase();

    // Save the latest launch time
    const launchTime = new Date();

    localStorage.setItem("lastLaunch", launchTime.toLocaleString());

    document.getElementById("last-launched").textContent =
        localStorage.getItem("lastLaunch");

    // Check network connection
    const status = document.getElementById("connection-status");

    if (window.location.protocol === "file:") {

        status.textContent =
            "Local file opened. Please use Live Preview to test the network.";

        status.style.color = "red";

    } else {

        status.textContent =
            "Connection Successful! Website is running through a local server.";

    }

});