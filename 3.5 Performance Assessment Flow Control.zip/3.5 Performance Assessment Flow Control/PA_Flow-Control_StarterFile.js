/*
    Author: Irvin Vega
    Date: November 3, 2026
    Purpose: 3.5 performance assessment flow control
*/

/* =========================================
   GREENWAY PARK TRAIL DATA
========================================= */

const trails = [

    { name: "River Walk", difficulty: "low", time: 20 },

    { name: "Forest Loop", difficulty: "medium", time: 45 },

    { name: "Hill Summit Trail", difficulty: "high", time: 90 },

    { name: "Lake Side Path", difficulty: "low", time: 30 },

    { name: "Rock Ridge Trail", difficulty: "high", time: 75 },

    { name: "Meadow Trail", difficulty: "low", time: 25 },

    { name: "Waterfall Adventure", difficulty: "medium", time: 60 },

    { name: "Student IRVVEG6401 Trail", difficulty: "high", time: 100 }

];


/* =========================================
   DISPLAY TRAILS VIA LOOP
========================================= */

const trailContainer = document.getElementById("trailContainer");

// Loop through all trails and create trail cards

for (let i = 0; i < trails.length; i++) {

    const trail = trails[i];

    const card = document.createElement("article");

    card.className = "card";

    card.innerHTML = `
        <h3>${trail.name}</h3>
        <p>Difficulty: ${trail.difficulty}</p>
        <p>Average Time: ${trail.time} minutes</p>
    `;

    trailContainer.appendChild(card);

}


/* =========================================
   FORM LOGIC
========================================= */

const trailForm = document.getElementById("trailForm");

const result = document.getElementById("result");

trailForm.addEventListener("submit", function(event) {

    // Prevent the page from refreshing

    event.preventDefault();

    // Get the visitor's selections

    const pets = document.querySelector('input[name="pets"]:checked').value;

    const experience = document.getElementById("experience").value;

    let recommendedTrail = "River Walk";

    // Conditional logic for trail recommendations

    if (pets === "yes" && experience === "low") {

        recommendedTrail = "River Walk";

    } 
    else if (pets === "yes" && (experience === "medium" || experience === "high")) {

        recommendedTrail = "Forest Loop";

    } 
    else if (pets === "no" && experience === "low") {

        recommendedTrail = "Lake Side Path";

    } 
    else if (pets === "no" && experience === "medium") {

        recommendedTrail = "Forest Loop";

    } 
    else if (pets === "no" && experience === "high") {

        recommendedTrail = "Rock Ridge Trail";

    } 
    else {

        recommendedTrail = "River Walk";

    }

    // Find the recommended trail in the array

    const selectedTrail = trails.find(function(trail) {

        return trail.name === recommendedTrail;

    });

    // Display the recommendation

    result.innerHTML = `
        <h3>Your Recommended Trail</h3>
        <p><strong>Trail:</strong> ${selectedTrail.name}</p>
        <p><strong>Difficulty:</strong> ${selectedTrail.difficulty}</p>
        <p><strong>Average Time:</strong> ${selectedTrail.time} minutes</p>
    `;

});