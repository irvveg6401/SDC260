/*
   Author: Irvin Vega
   Date: 11/08/2026
   Purpose: 5.4 Performance Assessment Launch Day
*/

// Get HTML elements
const heroTitle = document.getElementById("heroTitle");
const heroText = document.getElementById("heroText");
const connectionStatus = document.getElementById("connectionStatus");
const lastOnline = document.getElementById("lastOnline");

const hostInfo = document.getElementById("hostInfo");
const portInfo = document.getElementById("portInfo");
const protocolInfo = document.getElementById("protocolInfo");

const refreshButton = document.getElementById("refreshButton");

// Check if the page is running through a local server
function checkConnection() {

    const isLive = window.location.protocol === "http:" ||
                   window.location.protocol === "https:";

    if (isLive) {

        // Activate Uplink Mode
        document.body.classList.add("uplink-mode");

        heroTitle.textContent = "UPLINK MODE ACTIVE";
        heroText.textContent = "Satellite uplink successfully established.";

        connectionStatus.textContent = "ONLINE";

        // Display system information
        hostInfo.textContent = window.location.hostname;
        portInfo.textContent = window.location.port || "Default Port";
        protocolInfo.textContent = window.location.protocol.replace(":", "").toUpperCase();

        // Save the current launch time in a cookie
        const launchTime = new Date().toLocaleString();

        document.cookie = "lastUplink=" + encodeURIComponent(launchTime) +
                          "; max-age=2592000; path=/; SameSite=Lax";

        // Display the saved launch time
        const savedTime = getCookie("lastUplink");

        lastOnline.textContent = savedTime;

    } else {

        // Activate Ground Standby Mode
        document.body.classList.remove("uplink-mode");

        heroTitle.textContent = "GROUND STANDBY";
        heroText.textContent = "Awaiting Uplink Authorization...";

        connectionStatus.textContent = "OFFLINE";

        hostInfo.textContent = "Unavailable";
        portInfo.textContent = "Unavailable";
        protocolInfo.textContent = "FILE";

        // Read the previous launch time
        const savedTime = getCookie("lastUplink");

        if (savedTime) {
            lastOnline.textContent = savedTime;
        } else {
            lastOnline.textContent = "No uplink records found.";
        }
    }
}

// Function to read cookies
function getCookie(name) {

    const cookies = document.cookie.split(";");

    for (let cookie of cookies) {

        cookie = cookie.trim();

        if (cookie.startsWith(name + "=")) {
            return decodeURIComponent(cookie.substring(name.length + 1));
        }
    }

    return "";
}

// Refresh button
refreshButton.addEventListener("click", function() {
    location.reload();
});

// Run connection check when page loads
checkConnection();