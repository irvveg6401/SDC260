// SBR Clothing Week 3 JavaScript | Irvin Vega
// Product records are stored in an array and displayed with a loop.
const products = [
 {id:1,name:"Classic Tee",description:"Soft cotton T-shirt for everyday wear.",price:24.99,category:"T-SHIRT"},
 {id:2,name:"Essential Hoodie",description:"A relaxed-fit hoodie for cooler days.",price:49.99,category:"HOODIE"},
 {id:3,name:"Everyday Jeans",description:"Versatile denim with a modern fit.",price:44.99,category:"DENIM"},
 {id:4,name:"SBR Graphic Tee",description:"A casual graphic tee with a clean look.",price:27.99,category:"GRAPHIC TEE"},
 {id:5,name:"Classic Joggers",description:"Comfortable joggers for daily activities.",price:34.99,category:"JOGGERS"},
 {id:6,name:"Zip-Up Jacket",description:"A lightweight layer for changing weather.",price:54.99,category:"JACKET"},
 {id:7,name:"Crewneck Sweatshirt",description:"A comfortable crewneck everyday essential.",price:42.99,category:"SWEATSHIRT"},
 {id:8,name:"Cargo Pants",description:"Functional casual pants with a modern style.",price:46.99,category:"CARGO"},
 {id:9,name:"Everyday Cap",description:"A simple adjustable cap to finish your look.",price:19.99,category:"ACCESSORY"},
 {id:10,name:"Canvas Tote",description:"A reusable tote for everyday essentials.",price:16.99,category:"ACCESSORY"}
];
const money = value => `$${value.toFixed(2)}`;
function getCart(){try{return JSON.parse(localStorage.getItem("sbrCart"))||[]}catch{return []}}
function saveCart(cart){localStorage.setItem("sbrCart",JSON.stringify(cart));updateCartCount()}
function updateCartCount(){const count=getCart().reduce((sum,item)=>sum+item.quantity,0);document.querySelectorAll(".cart-count").forEach(el=>el.textContent=count)}
function displayProducts(){
 const container=document.getElementById("product-container"); if(!container)return;
 container.innerHTML="";
 for(let i=0;i<products.length;i++){
  const product=products[i], card=document.createElement("article");card.className="product-card";
  card.innerHTML=`<div class="product-art" role="img" aria-label="${product.category} product illustration">${product.category}</div>
   <h3>${product.name}</h3><p>${product.description}</p><div class="product-price">${money(product.price)}</div>
   <button type="button" data-product-id="${product.id}">Add to Cart</button>`;
  container.appendChild(card);
 }
 container.addEventListener("click",event=>{const button=event.target.closest("button[data-product-id]");if(button)addToCart(Number(button.dataset.productId))});
}
function addToCart(id){const product=products.find(item=>item.id===id);if(!product)return;const cart=getCart();const found=cart.find(item=>item.id===id);if(found)found.quantity++;else cart.push({id,quantity:1});saveCart(cart);alert(`${product.name} was added to your cart.`)}
function renderCart(){
 const container=document.getElementById("cart-items");if(!container)return;
 const cart=getCart();container.innerHTML="";
 if(!cart.length){container.innerHTML='<div class="empty-cart"><p>Your cart is currently empty.</p><a class="button" href="#products">Continue Shopping</a></div>';document.getElementById("cart-total").textContent=money(0);return}
 cart.forEach(item=>{const product=products.find(p=>p.id===item.id);if(!product)return;const row=document.createElement("div");row.className="cart-row";
 row.innerHTML=`<div><h3>${product.name}</h3><p>${money(product.price)} each</p></div>
 <label>Qty <input class="quantity-control" type="number" min="1" max="20" value="${item.quantity}" data-qty="${item.id}" aria-label="Quantity for ${product.name}"></label>
 <strong>${money(product.price*item.quantity)}</strong><button type="button" class="remove-button" data-remove="${item.id}">Remove</button>`;
 container.appendChild(row)});
 document.getElementById("cart-total").textContent=money(cart.reduce((sum,item)=>{const p=products.find(x=>x.id===item.id);return sum+(p?p.price*item.quantity:0)},0));
}
function handleCartChanges(event){
 if(event.target.matches("[data-qty]")){const id=Number(event.target.dataset.qty),qty=Math.max(1,Math.min(20,Number(event.target.value)||1));const cart=getCart();const item=cart.find(x=>x.id===id);if(item)item.quantity=qty;saveCart(cart);renderCart()}
 if(event.target.matches("[data-remove]")){saveCart(getCart().filter(x=>x.id!==Number(event.target.dataset.remove)));renderCart()}
}
function validateEmail(value){return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)}
function showMessage(elementId,message,type){const el=document.getElementById(elementId);if(el){el.textContent=message;el.className=`form-message ${type||""}`}}
function setupContactForm(){
 const form=document.getElementById("contact-form");if(!form)return;
 form.addEventListener("submit",event=>{event.preventDefault();const email=form.email.value.trim(),message=form.message.value.trim();
 if(!form.checkValidity()){form.reportValidity();showMessage("contact-feedback","Please complete all required fields correctly.","error");return}
 if(!validateEmail(email)){showMessage("contact-feedback","Enter a valid email address.","error");form.email.focus();return}
 if(message.length<5){showMessage("contact-feedback","Please enter a message with at least 5 characters.","error");form.message.focus();return}
 showMessage("contact-feedback","Thank you! Your message has been validated. This demo does not send messages to a server.","success");form.reset();
 });
}
const coupons={SBR10:10,SBR15:15,WELCOME20:20};
function calculateCheckout(){
 const cart=getCart(),subtotal=cart.reduce((sum,item)=>{const p=products.find(x=>x.id===item.id);return sum+(p?p.price*item.quantity:0)},0);
 const code=(document.getElementById("coupon-code")?.value||"").trim().toUpperCase();
 const discountRate=code?coupons[code]:0;const discount=subtotal*discountRate/100;const total=subtotal-discount;
 const subEl=document.getElementById("checkout-subtotal"),discountEl=document.getElementById("checkout-discount"),totalEl=document.getElementById("checkout-total");
 if(subEl)subEl.textContent=money(subtotal);if(discountEl)discountEl.textContent=`-${money(discount)}`;if(totalEl)totalEl.textContent=money(total);
 if(code)showMessage("coupon-feedback",discountRate?`${code} applied: ${discountRate}% off.`:"That coupon code is not valid.",""+(discountRate?"success":"error"));
 return {subtotal,discount,total,discountRate,code};
}
function setupCoupon(){const btn=document.getElementById("apply-coupon");if(btn)btn.addEventListener("click",calculateCheckout)}
function setupCheckoutForm(){
 const form=document.getElementById("checkout-form");if(!form)return;
 calculateCheckout();setupCoupon();
 form.addEventListener("submit",event=>{event.preventDefault();
 if(!form.checkValidity()){form.reportValidity();showMessage("checkout-feedback","Please complete all required shipping and payment fields.","error");return}
 const card=form.cardNumber.value.replace(/\s/g,""),expiry=form.expiration.value,cvv=form.securityCode.value;
 if(!/^\d{13,19}$/.test(card)){showMessage("checkout-feedback","Enter a valid test card number containing 13 to 19 digits.","error");form.cardNumber.focus();return}
 if(!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry)){showMessage("checkout-feedback","Use MM/YY for the expiration date.","error");form.expiration.focus();return}
 if(!/^\d{3,4}$/.test(cvv)){showMessage("checkout-feedback","Security code must contain 3 or 4 digits.","error");form.securityCode.focus();return}
 if(!getCart().length){showMessage("checkout-feedback","Your cart is empty. Add a product before checkout.","error");return}
 const result=calculateCheckout();
 showMessage("checkout-feedback",`Checkout form validated. Demo order total: ${money(result.total)}. No payment was processed and card details were not saved.`,"success");
 form.reset();
 });
}
document.addEventListener("DOMContentLoaded",()=>{displayProducts();updateCartCount();renderCart();const cart=document.getElementById("cart-items");if(cart)cart.addEventListener("change",handleCartChanges);if(cart)cart.addEventListener("click",handleCartChanges);setupContactForm();setupCheckoutForm()});
