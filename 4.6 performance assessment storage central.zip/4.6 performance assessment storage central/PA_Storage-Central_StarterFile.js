/*
    Author: Irvin Vega
    Date: 11/07/2026
    Purpose: 4.6 Performance Assessment - Storage Central
*/

// =========================================
// STEP 1: PRODUCT LIST
// =========================================

const products = [
    {
        id: 1,
        name: "Handmade Bookmark",
        price: 8.00,
        stock: 10,
        image: "images/bookmark.png",
        description: "A beautiful handmade bookmark perfect for book lovers."
    },
    {
        id: 2,
        name: "Handmade Candle",
        price: 15.00,
        stock: 8,
        image: "images/candle.png",
        description: "A handcrafted candle that brings warmth to any room."
    },
    {
        id: 3,
        name: "Ceramic Coasters",
        price: 20.00,
        stock: 6,
        image: "images/coasters.png",
        description: "A unique set of handcrafted coasters for your home."
    },
    {
        id: 4,
        name: "Macrame Wall Hanging",
        price: 35.00,
        stock: 5,
        image: "images/macrame.png",
        description: "A handmade decorative wall hanging with a natural design."
    },
    {
        id: 5,
        name: "Handmade Mug",
        price: 25.00,
        stock: 7,
        image: "images/mug.png",
        description: "A handcrafted mug perfect for coffee or tea."
    },
    {
        id: 6,
        name: "Knitted Scarf",
        price: 30.00,
        stock: 4,
        image: "images/scarf.png",
        description: "A soft handmade scarf designed to keep you warm."
    }
];


// =========================================
// STEP 2: LOAD SAVED INFORMATION
// =========================================

// Load the shopping cart from localStorage.
let cart = JSON.parse(localStorage.getItem("craftCart")) || [];

// Load saved inventory.
let savedStock = JSON.parse(localStorage.getItem("craftStock"));

if (savedStock) {
    products.forEach(product => {
        product.stock = savedStock[product.id];
    });
}

// Load the number of items added during this session.
let sessionCount = Number(sessionStorage.getItem("sessionCount")) || 0;


// =========================================
// STEP 3: DISPLAY PRODUCTS
// =========================================

function displayProducts() {

    const productGrid = document.getElementById("product-grid");

    productGrid.innerHTML = "";

    products.forEach(product => {

        productGrid.innerHTML += `
            <article class="product-card ${product.stock === 0 ? 'out-of-stock' : ''}"
                     data-id="${product.id}">

                <img src="${product.image}" alt="${product.name}">

                <div class="product-content">

                    <h3>${product.name}</h3>

                    <p>${product.description}</p>

                    <p class="price">$${product.price.toFixed(2)}</p>

                    <p>
                        Available Stock:
                        <span>${product.stock}</span>
                    </p>

                    <button class="add-to-cart"
                            data-id="${product.id}"
                            ${product.stock === 0 ? "disabled" : ""}>
                        ${product.stock === 0 ? "Out of Stock" : "Add to Cart"}
                    </button>

                </div>
            </article>
        `;

    });

}


// =========================================
// STEP 4: DISPLAY SHOPPING CART
// =========================================

function displayCart() {

    const cartItems = document.getElementById("cart-items");

    cartItems.innerHTML = "";

    let totalItems = 0;

    let totalPrice = 0;

    if (cart.length === 0) {

        cartItems.innerHTML = "<p>Your cart is empty.</p>";

    }

    cart.forEach(item => {

        totalItems += item.quantity;

        totalPrice += item.price * item.quantity;

        cartItems.innerHTML += `
            <div class="cart-item">

                <h3>${item.name}</h3>

                <p>Price: $${item.price.toFixed(2)}</p>

                <p>Quantity: ${item.quantity}</p>

                <p>Subtotal: $${(item.price * item.quantity).toFixed(2)}</p>

                <button class="decrease" data-id="${item.id}">-</button>

                <button class="increase" data-id="${item.id}">+</button>

                <button class="remove" data-id="${item.id}">Remove</button>

            </div>
        `;

    });

    document.getElementById("cart-count").textContent = totalItems;

    document.getElementById("cart-total").textContent =
        totalPrice.toFixed(2);

}


// =========================================
// STEP 5: SAVE INFORMATION
// =========================================

function saveInformation() {

    localStorage.setItem("craftCart", JSON.stringify(cart));

    let stockData = {};

    products.forEach(product => {
        stockData[product.id] = product.stock;
    });

    localStorage.setItem("craftStock", JSON.stringify(stockData));

    sessionStorage.setItem("sessionCount", sessionCount);

    document.getElementById("session-count").textContent =
        sessionCount;

    console.log("Shopping Cart:", localStorage.getItem("craftCart"));

    console.log("Inventory:", localStorage.getItem("craftStock"));

    console.log("Session Items:", sessionStorage.getItem("sessionCount"));

    console.log("Cookies:", document.cookie);

}


// =========================================
// STEP 6: ADD PRODUCTS TO CART
// =========================================

function addToCart(productId) {

    const product = products.find(item => item.id === productId);

    if (product.stock > 0) {

        const cartItem = cart.find(item => item.id === productId);

        if (cartItem) {

            cartItem.quantity++;

        } else {

            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            });

        }

        product.stock--;

        sessionCount++;

        // Visual feedback: the notification appears when a product is added.
        document.getElementById("notification").textContent =
            product.name + " added to your cart!";

        document.getElementById("notification").classList.add("show");

        setTimeout(() => {
            document.getElementById("notification").classList.remove("show");
        }, 2000);

        displayProducts();

        displayCart();

        saveInformation();

    }

}


// =========================================
// STEP 7: CHANGE PRODUCT QUANTITY
// =========================================

function changeQuantity(productId, amount) {

    const product = products.find(item => item.id === productId);

    const cartItem = cart.find(item => item.id === productId);

    if (amount > 0 && product.stock === 0) {
        return;
    }

    if (cartItem) {

        cartItem.quantity += amount;

        product.stock -= amount;

        if (cartItem.quantity <= 0) {

            cart = cart.filter(item => item.id !== productId);

        }

        displayProducts();

        displayCart();

        saveInformation();

    }

}


// =========================================
// STEP 8: REMOVE PRODUCT FROM CART
// =========================================

function removeFromCart(productId) {

    const cartItem = cart.find(item => item.id === productId);

    const product = products.find(item => item.id === productId);

    if (cartItem && product) {

        product.stock += cartItem.quantity;

        cart = cart.filter(item => item.id !== productId);

        displayProducts();

        displayCart();

        saveInformation();

    }

}


// =========================================
// STEP 9: CLEAR SHOPPING CART
// =========================================

function clearCart() {

    cart.forEach(item => {

        const product = products.find(product => product.id === item.id);

        product.stock += item.quantity;

    });

    cart = [];

    displayProducts();

    displayCart();

    saveInformation();

}


// =========================================
// STEP 10: SAVE PURCHASE COOKIE
// =========================================

function savePurchaseCookie(purchasedProducts) {

    document.cookie =
        "lastPurchased=" +
        encodeURIComponent(JSON.stringify(purchasedProducts)) +
        "; max-age=2592000; path=/; SameSite=Lax";

}


// Display products saved in the cookie.
function displayPurchaseHistory() {

    const purchaseHistory = document.getElementById("last-purchased");

    let savedPurchase = document.cookie.split("; ").find(
        cookie => cookie.startsWith("lastPurchased=")
    );

    if (savedPurchase) {

        let purchasedProducts = JSON.parse(
            decodeURIComponent(savedPurchase.substring("lastPurchased=".length))
        );

        purchaseHistory.textContent =
            purchasedProducts.map(item => item.name).join(", ");

    }

}


// =========================================
// STEP 11: CHECKOUT
// =========================================

function checkout() {

    if (cart.length === 0) {

        alert("Your cart is empty!");

        return;

    }

    let totalItems = 0;

    let totalPrice = 0;

    cart.forEach(item => {

        totalItems += item.quantity;

        totalPrice += item.price * item.quantity;

    });

    // Save purchased products in the cookie.
    savePurchaseCookie(cart);

    alert(
        "Thank you for shopping with us!\n\n" +
        "Total Items Purchased: " + totalItems +
        "\nTotal Cost: $" + totalPrice.toFixed(2)
    );

    // Clear the cart after checkout without restoring purchased stock.
    cart = [];

    displayCart();

    displayProducts();

    displayPurchaseHistory();

    saveInformation();

}


// =========================================
// STEP 12: OUT OF STOCK TOOLTIP
// =========================================

document.addEventListener("mousemove", function(event) {

    const tooltip = document.getElementById("mouse-tooltip");

    const card = event.target.closest(".product-card");

    if (card && card.classList.contains("out-of-stock")) {

        tooltip.style.left = event.clientX + 15 + "px";

        tooltip.style.top = event.clientY + 15 + "px";

        tooltip.classList.add("show");

    } else {

        tooltip.classList.remove("show");

    }

});


// =========================================
// STEP 13: BUTTON EVENTS
// =========================================

// Add to Cart buttons.
document.getElementById("product-grid").addEventListener("click", function(event) {

    if (event.target.classList.contains("add-to-cart")) {

        let productId = Number(event.target.dataset.id);

        addToCart(productId);

    }

});


// Shopping cart buttons.
document.getElementById("cart-items").addEventListener("click", function(event) {

    let productId = Number(event.target.dataset.id);

    if (event.target.classList.contains("increase")) {

        changeQuantity(productId, 1);

    }

    if (event.target.classList.contains("decrease")) {

        changeQuantity(productId, -1);

    }

    if (event.target.classList.contains("remove")) {

        removeFromCart(productId);

    }

});


// Clear Cart button.
document.getElementById("clear-cart").addEventListener("click", clearCart);


// Checkout button.
document.getElementById("checkout").addEventListener("click", checkout);


// =========================================
// STEP 14: START THE STORE
// =========================================

displayProducts();

displayCart();

displayPurchaseHistory();

document.getElementById("session-count").textContent = sessionCount;

saveInformation();

console.log("Willow & Pine Crafts is ready!");